package modele;

public class Case {
    private int valeur;

    public Case(int _valeur) {
        valeur = _valeur;
    }

    public int getValeur() {
        return valeur;
    }

}
