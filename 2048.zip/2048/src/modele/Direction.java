package modele;

public enum Direction {
    haut, bas, gauche, droite
}
